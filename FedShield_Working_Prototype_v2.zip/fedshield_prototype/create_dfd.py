from PIL import Image, ImageDraw, ImageFont
from pathlib import Path

OUT=Path(__file__).resolve().parent/'results'/'FedShield_DFD_Level1.png'
W,H=1800,1050
img=Image.new('RGB',(W,H),'#f7f9fc'); d=ImageDraw.Draw(img)

def font(size,bold=False):
    paths=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
    return ImageFont.truetype(paths[0],size)

title=font(44,True); h=font(24,True); body=font(20); small=font(17)

def box(xy,fill,outline='#18324b',radius=18,width=3):
    d.rounded_rectangle(xy,radius=radius,fill=fill,outline=outline,width=width)

def center_text(xy,text,f,fill='#0c1c2d',spacing=5):
    x1,y1,x2,y2=xy
    lines=text.split('\n'); heights=[d.textbbox((0,0),l,font=f)[3] for l in lines]
    total=sum(heights)+spacing*(len(lines)-1); y=(y1+y2-total)/2
    for l,hh in zip(lines,heights):
        bb=d.textbbox((0,0),l,font=f); tw=bb[2]
        d.text(((x1+x2-tw)/2,y),l,font=f,fill=fill); y+=hh+spacing

def arrow(p1,p2,label=None,color='#3d566f',dash=False,label_offset=(0,0)):
    # simple straight arrow
    d.line([p1,p2],fill=color,width=4)
    import math
    ang=math.atan2(p2[1]-p1[1],p2[0]-p1[0]); L=17
    a1=ang+2.65; a2=ang-2.65
    q1=(p2[0]+L*math.cos(a1),p2[1]+L*math.sin(a1)); q2=(p2[0]+L*math.cos(a2),p2[1]+L*math.sin(a2))
    d.polygon([p2,q1,q2],fill=color)
    if label:
        mx=(p1[0]+p2[0])/2+label_offset[0]; my=(p1[1]+p2[1])/2+label_offset[1]
        bb=d.textbbox((0,0),label,font=small); pad=6
        d.rounded_rectangle((mx-bb[2]/2-pad,my-bb[3]/2-pad,mx+bb[2]/2+pad,my+bb[3]/2+pad),radius=6,fill='#ffffff',outline='#d7e0e9')
        d.text((mx-bb[2]/2,my-bb[3]/2),label,font=small,fill='#435b72')

# title
center_text((0,25,W,95),'FedShield — Level 1 Data Flow Diagram',title)
d.text((0,95,W,130)[0:2] if False else (0,0),'',font=small)
center_text((0,92,W,130),'Privacy-preserving federated graph fraud detection workflow',small,fill='#647b91')

# external entities
box((55,190,325,325),'#e8f2ff')
center_text((55,190,325,325),'BANK A\nCLIENT 1',h)
box((55,430,325,565),'#e8f2ff')
center_text((55,430,325,565),'BANK B\nCLIENT 2',h)
box((55,670,325,805),'#e8f2ff')
center_text((55,670,325,805),'BANK C\nCLIENT 3',h)

# processes
box((430,250,760,365),'#eef8f5')
center_text((430,250,760,365),'P1  Local Data Preparation\n+ Transaction Graph',h)
box((430,500,760,615),'#eef8f5')
center_text((430,500,760,615),'P2  Local GCN Training',h)
box((850,375,1180,490),'#e7fbf6')
center_text((850,375,1180,490),'P3  Privacy Layer\nClipping + DP Noise',h)
box((1280,375,1610,490),'#eaf2ff')
center_text((1280,375,1610,490),'P4  Federated Server\nFedAvg Aggregation',h)

# data stores
box((430,650,760,755),'#fff7e5')
center_text((430,650,760,755),'D1  Local Graph /\nTransaction Data',h)
box((1280,610,1610,715),'#fff7e5')
center_text((1280,610,1610,715),'D2  Global Model',h)

# admin
box((1280,820,1610,930),'#f3ecff')
center_text((1280,820,1610,930),'ADMIN / ANALYST',h)

# flows from banks to local preparation
arrow((325,255),(430,295),'transactions',label_offset=(0,-18))
arrow((325,495),(430,310),'transactions',label_offset=(0,0))
arrow((325,735),(430,325),'transactions',label_offset=(0,18))
# local preparation -> local data store -> GCN
arrow((595,365),(595,650),'prepared graph',label_offset=(105,0))
arrow((595,650),(595,615),'graph data',label_offset=(90,0))
# GCN -> privacy -> server
arrow((760,555),(850,432),'local model update',label_offset=(0,-22))
arrow((1180,432),(1280,432),'private model update',label_offset=(0,-22))
# server -> global model
arrow((1445,490),(1445,610),'global model',label_offset=(95,0))
# global model -> local GCN for next round, routed below the privacy process
# two-segment path: from store left edge down, then left, then up into P2
d.line([(1280,665),(1220,665),(1220,790),(700,790),(700,615)],fill='#3d566f',width=4)
d.polygon([(700,615),(683,632),(717,632)],fill='#3d566f')
label='updated global model'; bb=d.textbbox((0,0),label,font=small); mx,my=960,803; pad=6
d.rounded_rectangle((mx-bb[2]/2-pad,my-bb[3]/2-pad,mx+bb[2]/2+pad,my+bb[3]/2+pad),radius=6,fill='#ffffff',outline='#d7e0e9')
d.text((mx-bb[2]/2,my-bb[3]/2),label,font=small,fill='#435b72')
# server -> analyst
arrow((1445,715),(1445,820),'fraud risk + metrics',label_offset=(115,0))

# note
box((400,865,1120,955),'#eef4f8',outline='#cbd8e4',width=2)
center_text((400,865,1120,955),'RAW TRANSACTION DATA STAYS LOCAL.\nOnly protected model information is exchanged.',body,fill='#35516a')

# legend
x=55;y=975
d.rounded_rectangle((x,y,x+22,y+22),radius=5,fill='#e8f2ff',outline='#18324b'); d.text((x+32,y-1),'External entity',font=small,fill='#50677d')
x=250;d.rounded_rectangle((x,y,x+22,y+22),radius=5,fill='#eef8f5',outline='#18324b'); d.text((x+32,y-1),'Process',font=small,fill='#50677d')
x=430;d.rounded_rectangle((x,y,x+22,y+22),radius=5,fill='#fff7e5',outline='#18324b'); d.text((x+32,y-1),'Data store',font=small,fill='#50677d')
img.save(OUT,quality=95)
print(OUT)
