from pathlib import Path
import json, textwrap
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, FancyArrowPatch
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

ROOT=Path('/mnt/data/fedshield_prototype'); RES=ROOT/'results'
with open(RES/'results.json') as f: r=json.load(f)

# 1) Proper DFD
fig,ax=plt.subplots(figsize=(13.33,7.5)); ax.set_xlim(0,13.33); ax.set_ylim(0,7.5); ax.axis('off')

def box(x,y,w,h,text,kind='process'):
    if kind=='entity': ec='black'; fc='white'; lw=1.8
    elif kind=='store': ec='black'; fc='white'; lw=1.5
    else: ec='black'; fc='white'; lw=1.4
    p=Rectangle((x,y),w,h,facecolor=fc,edgecolor=ec,linewidth=lw); ax.add_patch(p)
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=12,weight='bold' if kind!='store' else 'normal')

def arrow(x1,y1,x2,y2,label):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='->',mutation_scale=14,linewidth=1.2))
    ax.text((x1+x2)/2,(y1+y2)/2+0.12,label,ha='center',va='center',fontsize=9)

ax.text(6.66,7.2,'FedShield Data Flow Diagram (DFD)',ha='center',fontsize=22,weight='bold')
box(.4,5.4,2.0,1.0,'Bank A / Client 1','entity'); box(.4,3.2,2.0,1.0,'Bank B / Client 2','entity'); box(.4,1.0,2.0,1.0,'Bank C / Client 3','entity')
box(3.1,4.8,2.2,1.1,'1. Data\nPreparation'); box(3.1,2.0,2.2,1.1,'2. Local GCN\nTraining')
box(6.2,3.3,2.3,1.2,'3. Privacy\nAggregation'); box(9.3,3.3,2.4,1.2,'4. FedAvg\nServer')
box(9.5,1.0,2.0,1.0,'Global Model','store'); box(6.4,.65,2.1,1.0,'Transaction\nData','store'); box(11.7,5.4,1.2,1.0,'Admin /\nAnalyst','entity')
arrow(2.4,5.9,3.1,5.35,'transactions'); arrow(2.4,3.7,3.1,2.55,'transactions'); arrow(2.4,1.5,3.1,2.2,'transactions')
arrow(5.3,5.25,6.2,4.0,'local graph + updates'); arrow(5.3,2.55,6.2,3.55,'model updates')
arrow(8.5,3.9,9.3,3.9,'private updates'); arrow(10.5,3.3,10.5,2.0,'global model'); arrow(10.5,2.0,8.5,1.15,'prediction / model')
arrow(11.7,5.9,11.7,4.5,'alerts / metrics'); arrow(8.5,1.15,11.7,5.4,'fraud risk')
ax.text(6.66,0.15,'Raw transaction data stays at clients; only model information is exchanged in the federated workflow.',ha='center',fontsize=10)
fig.savefig(RES/'fedshield_dfd.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 2) Metrics figure
hist=r['history']; rounds=[x['round'] for x in hist]
fig,ax=plt.subplots(figsize=(11,5.5));
ax.plot(rounds,[x['f1'] for x in hist],marker='o',label='F1'); ax.plot(rounds,[x['auc'] for x in hist],marker='o',label='AUC'); ax.plot(rounds,[x['recall'] for x in hist],marker='o',label='Recall')
ax.set_xlabel('Federated Round'); ax.set_ylabel('Score'); ax.set_title('FedShield Federated Training Metrics'); ax.grid(alpha=.25); ax.legend(); fig.tight_layout(); fig.savefig(RES/'training_metrics.png',dpi=180); plt.close(fig)

# 3) Implementation screenshot-style dashboard
fig,ax=plt.subplots(figsize=(13.33,7.5)); ax.axis('off');
ax.text(.02,.94,'FedShield | Implementation Dashboard',fontsize=24,weight='bold',transform=ax.transAxes)
ax.text(.02,.895,'Privacy-Preserving Federated Graph Fraud Detection Prototype',fontsize=12,transform=ax.transAxes)
vals=[('Transactions',f"{r['rows']:,}"),('Clients',str(r['clients'])),('Rounds',str(r['rounds'])),('F1',f"{r['final']['f1']:.3f}"),('AUC',f"{r['final']['auc']:.3f}")]
for i,(a,b) in enumerate(vals):
    x=.02+i*.19; ax.add_patch(FancyBboxPatch((x,.72),.16,.12,boxstyle='round,pad=.01',facecolor='white',edgecolor='black')); ax.text(x+.08,.79,a,ha='center',fontsize=10); ax.text(x+.08,.745,b,ha='center',fontsize=22,weight='bold')
ax.text(.02,.64,'Federated Training Progress',fontsize=16,weight='bold')
for j,xr in enumerate(hist):
    y=.58-j*.075; ax.text(.02,y,f"Round {xr['round']}: F1 {xr['f1']:.3f} | Recall {xr['recall']:.3f} | AUC {xr['auc']:.3f}",fontsize=11)
    ax.add_patch(Rectangle((.44,y-.018),.45,.028,facecolor='white',edgecolor='black')); ax.add_patch(Rectangle((.44,y-.018),.45*min(xr['auc'],1),.028,facecolor='black'))
ax.text(.02,.18,'Sample Transaction Risk Monitor',fontsize=16,weight='bold')
rows=[]
import pandas as pd
s=pd.read_csv(RES/'scored_transactions.csv').head(6)
for _,q in s.iterrows(): rows.append([q['type'],f"{q['amount']:.0f}",q['nameOrig'],q['nameDest'],int(q['isFraud']),f"{q['risk_score']:.3f}",int(q['prediction'])])
tab=ax.table(cellText=rows,colLabels=['Type','Amount','Origin','Destination','Fraud','Risk','Pred'],loc='lower left',cellLoc='center',bbox=[.02,.02,.96,.13]); tab.auto_set_font_size(False); tab.set_fontsize(8)
fig.savefig(RES/'dashboard_screenshot.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 4) Implementation slides PPTX
prs=Presentation(); prs.slide_width=Inches(13.333); prs.slide_height=Inches(7.5)

def add_title(slide,title,sub=None):
    t=slide.shapes.add_textbox(Inches(.55),Inches(.25),Inches(12.2),Inches(.6)); tf=t.text_frame; tf.text=title; tf.paragraphs[0].font.size=Pt(28); tf.paragraphs[0].font.bold=True
    if sub:
        st=slide.shapes.add_textbox(Inches(.58),Inches(.85),Inches(12),Inches(.4)); st.text_frame.text=sub; st.text_frame.paragraphs[0].font.size=Pt(13)

s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Implementation: Working Prototype','PaySim-compatible data → transaction graph → local GCN → DP-inspired privacy → FedAvg')
s.shapes.add_picture(str(RES/'dashboard_screenshot.png'),Inches(.55),Inches(1.25),width=Inches(12.2))

s=prs.slides.add_slide(prs.slide_layouts[6]); add_title(s,'Implementation: Federated Training Results','3 simulated clients • 5 rounds • PyTorch GCN • FedAvg • gradient clipping + Gaussian noise')
s.shapes.add_picture(str(RES/'training_metrics.png'),Inches(.55),Inches(1.25),width=Inches(7.4))
box=s.shapes.add_textbox(Inches(8.25),Inches(1.45),Inches(4.3),Inches(4.9)); tf=box.text_frame
lines=[f"Rows processed: {r['rows']:,}",f"Fraud cases: {r['fraud_count']:,}",f"Clients: {r['clients']}",f"Federated rounds: {r['rounds']}",f"Final Accuracy: {r['final']['accuracy']:.3f}",f"Final Recall: {r['final']['recall']:.3f}",f"Final F1: {r['final']['f1']:.3f}",f"Final AUC: {r['final']['auc']:.3f}","Model saved: fedshield_gcn.pt"]
for i,line in enumerate(lines):
    p=tf.paragraphs[0] if i==0 else tf.add_paragraph(); p.text=line; p.font.size=Pt(17); p.space_after=Pt(8)
prs.save(ROOT/'FedShield_Implementation_Slides.pptx')
