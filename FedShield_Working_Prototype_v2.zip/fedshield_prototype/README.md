# FedShield Working Prototype

A review-ready prototype of the proposed privacy-preserving federated graph fraud detection workflow.

## What is implemented
- PaySim-compatible transaction ingestion (`data/raw/PS_20174392719_1491204439457_log.csv` if supplied)
- Automatic demo-data fallback with the same PaySim-style columns
- Transaction-to-account graph construction
- 3 simulated bank/client partitions
- 2-layer GCN implemented in PyTorch (without requiring PyG)
- Local client training
- FedAvg server aggregation
- DP-inspired gradient clipping + Gaussian noise during local training and aggregation
- Iterative federated rounds
- Fraud metrics: accuracy, precision, recall, F1, AUC, confusion matrix
- Saved global model and scored transactions
- Lightweight browser dashboard using only Python standard library

## Run
```bash
python train.py --limit 24000 --clients 3 --rounds 5 --epochs 1 --dp-noise 0.02
python dashboard.py
```
Open http://127.0.0.1:8000

## Full PaySim
Place the official full PaySim CSV at:
`data/raw/PS_20174392719_1491204439457_log.csv`
Then run with a suitable limit for your laptop, e.g.:
```bash
python train.py --limit 200000 --clients 3 --rounds 5 --epochs 1
```
Remove `--limit` if you intentionally want to process the full file and your hardware has enough RAM/time.

## Important prototype wording
This is a research/demo prototype, not a production banking system. The DP component is an educational DP-inspired mechanism using gradient clipping and Gaussian noise; a production implementation should use a formally audited DP library and privacy accounting.

The GCN represents accounts as nodes and transactions as edges. Fraud labels are propagated to source accounts for node-level graph learning, and transaction risk is read from the source account score. This is a practical prototype abstraction, not a claim that PaySim itself is inherently a graph dataset.

## Frontend
The prototype includes a redesigned local web dashboard with:
- KPI cards for transactions, fraud cases, F1, AUC, recall and precision
- federated training round visualization
- simulated client status cards
- privacy-layer status panel
- transaction risk monitoring table
- local "Run New Training" button that launches a fixed safe training configuration
- automatic dashboard refresh

Run:
```bash
python dashboard.py
```
Then open `http://127.0.0.1:8000`.

## Methodology DFD
Use `results/FedShield_DFD_Level1.png` as the Level-1 DFD in the methodology section, or use `FedShield_DFD_Slide.pptx` as a ready-made slide.
