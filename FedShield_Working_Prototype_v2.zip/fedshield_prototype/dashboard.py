from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, csv, html, subprocess, sys, threading

ROOT = Path(__file__).resolve().parent
RES = ROOT / 'results'


def load_json(name):
    p = RES / name
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding='utf-8'))


def load_transactions(limit=80):
    p = RES / 'scored_transactions.csv'
    if not p.exists():
        return []
    rows = []
    with p.open(newline='', encoding='utf-8') as f:
        for i, r in enumerate(csv.DictReader(f)):
            if i >= limit:
                break
            rows.append(r)
    return rows


def json_response(h, obj, status=200):
    data = json.dumps(obj).encode()
    h.send_response(status)
    h.send_header('Content-Type', 'application/json; charset=utf-8')
    h.send_header('Cache-Control', 'no-store')
    h.end_headers()
    h.wfile.write(data)


PAGE = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FedShield | Fraud Intelligence</title>
<style>
:root{--bg:#07111f;--panel:#0d1b2e;--panel2:#10243b;--line:#1e3854;--text:#edf5ff;--muted:#91a6bd;--accent:#35d6b1;--accent2:#4aa3ff;--danger:#ff6577;--warn:#f7c65f;--shadow:0 18px 45px rgba(0,0,0,.22)}
*{box-sizing:border-box} body{margin:0;background:linear-gradient(135deg,#06101d,#0a1727 48%,#07111f);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif}
.app{display:flex;min-height:100vh}.side{width:235px;background:#081524;border-right:1px solid var(--line);padding:22px 15px;position:fixed;inset:0 auto 0 0}.brand{display:flex;align-items:center;gap:10px;padding:7px 9px 25px}.logo{width:38px;height:38px;border-radius:12px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:grid;place-items:center;color:#04121e;font-weight:900}.brand b{font-size:18px}.brand small{display:block;color:var(--muted);font-size:10px;margin-top:2px}.nav{display:grid;gap:7px}.nav a{padding:12px 13px;border-radius:10px;color:#9db0c5;text-decoration:none;font-size:13px}.nav a.active,.nav a:hover{background:#10273d;color:#fff}.side .foot{position:absolute;bottom:20px;left:22px;right:22px;color:#607890;font-size:10px;line-height:1.5}
.main{margin-left:235px;width:calc(100% - 235px);padding:25px 31px 45px}.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:23px}.crumb{color:var(--muted);font-size:12px}.top h1{font-size:25px;margin:5px 0 0}.status{display:flex;align-items:center;gap:8px;background:#0d2134;border:1px solid var(--line);padding:9px 12px;border-radius:999px;font-size:11px;color:#b9c9d9}.dot{width:8px;height:8px;background:var(--accent);border-radius:50%;box-shadow:0 0 14px var(--accent)}
.hero{display:grid;grid-template-columns:1.5fr .9fr;gap:18px;margin-bottom:18px}.heroCard,.card{background:linear-gradient(145deg,rgba(16,36,59,.96),rgba(10,25,42,.96));border:1px solid var(--line);border-radius:16px;box-shadow:var(--shadow)}.heroCard{padding:24px;position:relative;overflow:hidden}.heroCard:after{content:"";position:absolute;width:220px;height:220px;border-radius:50%;background:rgba(53,214,177,.08);right:-70px;top:-90px}.eyebrow{font-size:11px;color:var(--accent);font-weight:700;letter-spacing:.12em;text-transform:uppercase}.heroCard h2{font-size:28px;margin:8px 0}.heroCard p{color:var(--muted);max-width:650px;line-height:1.55;font-size:13px;margin:0}.pills{display:flex;gap:8px;margin-top:17px;flex-wrap:wrap}.pill{font-size:10px;padding:7px 9px;border-radius:8px;background:#0a1c2e;border:1px solid var(--line);color:#b7c8d9}.pill b{color:#fff}.heroSide{padding:21px}.heroSide h3{margin:0 0 16px;font-size:14px}.metricline{display:flex;justify-content:space-between;padding:11px 0;border-bottom:1px solid #183149;font-size:12px}.metricline:last-child{border:0}.metricline span{color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:18px}.kpi{padding:17px}.kpi .label{color:var(--muted);font-size:11px}.kpi .num{font-size:25px;font-weight:800;margin:8px 0 4px}.kpi .sub{font-size:10px;color:#6f879e}.accent{color:var(--accent)}.blue{color:var(--accent2)}.warn{color:var(--warn)}.danger{color:var(--danger)}
.two{display:grid;grid-template-columns:1.35fr .65fr;gap:18px;margin-bottom:18px}.card{padding:18px}.cardHead{display:flex;justify-content:space-between;align-items:center;margin-bottom:15px}.cardHead h3{margin:0;font-size:14px}.cardHead span{font-size:10px;color:var(--muted)}
.chart{height:205px;display:flex;align-items:end;gap:10px;padding:10px 6px 25px;border-bottom:1px solid #20384f}.barWrap{height:100%;flex:1;display:flex;flex-direction:column;justify-content:end;align-items:center;gap:7px}.bar{width:72%;max-width:60px;border-radius:7px 7px 2px 2px;background:linear-gradient(180deg,var(--accent2),var(--accent));min-height:4px;box-shadow:0 5px 20px rgba(53,214,177,.12)}.barVal{font-size:9px;color:#a9bdd0}.barLab{font-size:9px;color:#6f879e}.clientGrid{display:grid;gap:10px}.client{background:#0a1a2b;border:1px solid #19344e;border-radius:11px;padding:12px}.clientTop{display:flex;justify-content:space-between;font-size:11px}.online{color:var(--accent);font-size:9px}.clientBar{height:5px;background:#142b42;border-radius:5px;margin-top:9px;overflow:hidden}.clientBar i{display:block;height:100%;background:var(--accent2);border-radius:5px}.clientMeta{display:flex;justify-content:space-between;color:#6f879e;font-size:9px;margin-top:7px}
.tableCard{padding:18px}.tableWrap{overflow:auto;border:1px solid #19344e;border-radius:11px}table{width:100%;border-collapse:collapse;min-width:800px}th,td{padding:11px 10px;border-bottom:1px solid #183149;text-align:left;font-size:10px;white-space:nowrap}th{color:#7890a7;background:#091a2b;font-weight:600}td{color:#c8d6e4}tr:last-child td{border-bottom:0}.risk{font-weight:800}.badge{display:inline-block;padding:4px 7px;border-radius:6px;font-size:9px}.high{background:rgba(255,101,119,.13);color:#ff8290}.low{background:rgba(53,214,177,.12);color:#54e1c0}.medium{background:rgba(247,198,95,.12);color:#f7c65f}
.footer{text-align:center;color:#536c83;font-size:9px;margin-top:20px}.btn{border:1px solid #2a587b;background:#0d2840;color:#d9ebfb;border-radius:9px;padding:9px 12px;font-size:10px;cursor:pointer}.btn:hover{background:#123551}.btn.primary{background:linear-gradient(135deg,#0f8f78,#1c6eb4);border:0;color:#fff}.btn:disabled{opacity:.5;cursor:not-allowed}.toolbar{display:flex;gap:8px;align-items:center}.note{font-size:10px;color:var(--muted);line-height:1.5}.progress{height:7px;background:#142a40;border-radius:9px;overflow:hidden}.progress i{display:block;height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2));width:0%}
@media(max-width:1000px){.side{display:none}.main{margin-left:0;width:100%;padding:18px}.hero,.two{grid-template-columns:1fr}.grid{grid-template-columns:repeat(2,1fr)}}
</style></head>
<body><div class="app">
<aside class="side"><div class="brand"><div class="logo">F</div><div><b>FedShield</b><small>Fraud Intelligence</small></div></div>
<nav class="nav"><a class="active" href="#overview">▣ Overview</a><a href="#training">◈ Federated Training</a><a href="#clients">◎ Clients</a><a href="#transactions">▤ Transactions</a><a href="#privacy">◉ Privacy Layer</a></nav>
<div class="foot">Prototype environment<br>Local simulation • PaySim-compatible<br>Research / academic demo</div></aside>
<main class="main"><div class="top"><div><div class="crumb">FEDSHIELD / CONTROL CENTER</div><h1>Fraud Detection Dashboard</h1></div><div class="status"><i class="dot"></i> System ready · local simulation</div></div>
<section id="overview" class="hero"><div class="heroCard"><div class="eyebrow">Privacy-preserving federated AI</div><h2>Collaborative fraud detection without pooling raw transactions.</h2><p>FedShield simulates multiple banking clients, trains a graph-based fraud model locally, perturbs sensitive training information, and aggregates model updates into a shared global model.</p><div class="pills"><div class="pill"><b>GCN</b> graph learning</div><div class="pill"><b>FedAvg</b> model aggregation</div><div class="pill"><b>DP</b> noise + clipping</div><div class="pill"><b>PaySim</b> transaction data</div></div></div><div class="heroSide card"><h3>Model Snapshot</h3><div class="metricline"><span>Global model</span><b id="modelStatus">Loaded</b></div><div class="metricline"><span>Data source</span><b id="source">—</b></div><div class="metricline"><span>Fraud rate</span><b id="fraudRate">—</b></div><div class="metricline"><span>Privacy noise</span><b id="noise">—</b></div><div class="metricline"><span>Last round</span><b id="lastRound">—</b></div></div></section>
<section class="grid" id="kpis"></section>
<section class="two" id="training"><div class="card"><div class="cardHead"><h3>Federated Training Progress</h3><span>F1 score by communication round</span></div><div class="chart" id="chart"></div><div style="margin-top:13px"><div class="note">The model improves across repeated local-training and server-aggregation rounds.</div></div></div>
<div class="card" id="privacy"><div class="cardHead"><h3>Privacy Layer</h3><span>Prototype controls</span></div><div class="metricline"><span>Raw data sharing</span><b class="accent">OFF</b></div><div class="metricline"><span>Gradient clipping</span><b class="accent">ON</b></div><div class="metricline"><span>Gaussian noise</span><b class="accent" id="privacyNoise">—</b></div><div class="metricline"><span>Federated aggregation</span><b class="accent">FedAvg</b></div><p class="note" style="margin-top:14px">The privacy mechanism is an educational prototype, not a formally audited production DP implementation.</p></div></section>
<section class="card" id="clients" style="margin-bottom:18px"><div class="cardHead"><h3>Federated Clients</h3><div class="toolbar"><span>Simulated institutions</span><button class="btn primary" id="trainBtn" onclick="retrain()">Run New Training</button></div></div><div class="clientGrid" id="clientsGrid"></div><div id="trainStatus" class="note" style="margin-top:10px"></div></section>
<section class="card tableCard" id="transactions"><div class="cardHead"><h3>Transaction Risk Monitor</h3><span>Latest scored transactions</span></div><div class="tableWrap"><table><thead><tr><th>Type</th><th>Amount</th><th>Origin</th><th>Destination</th><th>Fraud</th><th>Risk</th><th>Prediction</th></tr></thead><tbody id="tx"></tbody></table></div></section>
<div class="footer">FedShield · Centralized Banking Data Management System for Fraud Detection and Prevention · Academic Prototype</div>
</main></div>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
let RESULTS=null;
async function refresh(){
 const rr=await fetch('/api/results'); const d=await rr.json(); RESULTS=d;
 if(d.error){document.getElementById('trainStatus').textContent=d.error;return}
 const f=d.final||{};
 document.getElementById('source').textContent=(d.source||'').replace('synthetic ','').replace(' (full PaySim can be dropped into data/raw)','');
 document.getElementById('fraudRate').textContent=((d.fraud_rate||0)*100).toFixed(2)+'%';
 document.getElementById('noise').textContent=d.dp_noise;
 document.getElementById('privacyNoise').textContent=d.dp_noise;
 document.getElementById('lastRound').textContent=d.rounds;
 const cards=[['Transactions',Number(d.rows||0).toLocaleString(),'processed','accent'],['Fraud cases',Number(d.fraud_count||0).toLocaleString(),'labelled in dataset','danger'],['F1 Score',(f.f1||0).toFixed(3),'fraud classification','accent'],['AUC',(f.auc||0).toFixed(3),'discrimination quality','blue'],['Recall',(f.recall||0).toFixed(3),'fraud capture rate','warn'],['Precision',(f.precision||0).toFixed(3),'positive prediction quality','blue'],['Clients',d.clients,'simulated banks','accent'],['Rounds',d.rounds,'federated cycles','accent']];
 document.getElementById('kpis').innerHTML=cards.map(x=>`<div class="card kpi"><div class="label">${x[0]}</div><div class="num ${x[3]}">${x[1]}</div><div class="sub">${x[2]}</div></div>`).join('');
 document.getElementById('chart').innerHTML=(d.history||[]).map(x=>`<div class="barWrap"><div class="barVal">${x.f1.toFixed(3)}</div><div class="bar" style="height:${Math.max(5,x.f1*100)}%"></div><div class="barLab">R${x.round}</div></div>`).join('');
 const clients=Array.from({length:Number(d.clients||3)},(_,i)=>({name:'Bank '+String.fromCharCode(65+i),rows:Math.round((d.rows||0)/d.clients),status:'Online'}));
 document.getElementById('clientsGrid').innerHTML=clients.map(c=>`<div class="client"><div class="clientTop"><b>${c.name} / Client ${c.name.charCodeAt(5)-64}</b><span class="online">● ${c.status}</span></div><div class="clientBar"><i style="width:${Math.min(100,40+i*20)}%"></i></div><div class="clientMeta"><span>Local graph partition</span><span>~${c.rows.toLocaleString()} rows</span></div></div>`).join('');
 const tx=await (await fetch('/api/transactions')).json();
 document.getElementById('tx').innerHTML=tx.map(x=>{let r=Number(x.risk_score||0), cls=r>=.66?'high':r>=.33?'medium':'low';return `<tr><td>${esc(x.type)}</td><td>₹${Number(x.amount||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</td><td>${esc(x.nameOrig)}</td><td>${esc(x.nameDest)}</td><td>${x.isFraud==='1'?'<span class="badge high">YES</span>':'<span class="badge low">NO</span>'}</td><td class="risk ${cls}">${r.toFixed(3)}</td><td><span class="badge ${x.prediction==='1'?'high':'low'}">${x.prediction==='1'?'FRAUD RISK':'LEGITIMATE'}</span></td></tr>`}).join('');
}
async function retrain(){const b=document.getElementById('trainBtn'),s=document.getElementById('trainStatus');b.disabled=true;s.textContent='Running 5 federated rounds locally…';try{let r=await fetch('/api/train',{method:'POST'});let d=await r.json();s.textContent=d.ok?'Training complete. Dashboard refreshed.':'Training failed: '+d.error; if(d.ok) await refresh()}catch(e){s.textContent='Training request failed: '+e}finally{b.disabled=false}}
refresh(); setInterval(refresh,15000);
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        return

    def do_GET(self):
        if self.path.startswith('/api/results'):
            d = load_json('results.json')
            json_response(self, d or {'error': 'Run training first.'})
            return
        if self.path.startswith('/api/transactions'):
            json_response(self, load_transactions())
            return
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        self.wfile.write(PAGE.encode('utf-8'))

    def do_POST(self):
        if self.path.startswith('/api/train'):
            try:
                proc = subprocess.run([sys.executable, str(ROOT/'train.py'), '--limit','12000','--clients','3','--rounds','5','--epochs','1','--dp-noise','0.002'], cwd=ROOT, capture_output=True, text=True, timeout=240)
                if proc.returncode != 0:
                    json_response(self, {'ok':False,'error':proc.stderr[-1800:]}, 500)
                else:
                    json_response(self, {'ok':True,'message':'Training complete'})
            except Exception as e:
                json_response(self, {'ok':False,'error':str(e)}, 500)
            return
        json_response(self, {'error':'Not found'},404)


if __name__ == '__main__':
    print('FedShield dashboard: http://127.0.0.1:8000')
    ThreadingHTTPServer(('127.0.0.1',8000), Handler).serve_forever()
