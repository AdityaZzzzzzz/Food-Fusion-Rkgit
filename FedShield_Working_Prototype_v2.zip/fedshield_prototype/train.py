import os, json, math, random, argparse
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

ROOT=Path(__file__).resolve().parent
RAW=ROOT/'data'/'raw'
RES=ROOT/'results'
MOD=ROOT/'models'
RES.mkdir(parents=True, exist_ok=True); MOD.mkdir(parents=True, exist_ok=True)
SEED=42
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)

FEATURES=['amount','oldbalanceOrg','newbalanceOrig','oldbalanceDest','newbalanceDest','isFlaggedFraud','step']
TYPES=['CASH_OUT','TRANSFER','PAYMENT','CASH_IN','DEBIT']

def make_demo(path, n=24000):
    rng=np.random.default_rng(SEED)
    types=rng.choice(TYPES,size=n,p=[.36,.16,.36,.08,.04])
    step=rng.integers(1,744,size=n)
    amount=np.exp(rng.normal(7.5,1.2,n)).clip(1,500000)
    oldo=rng.exponential(50000,n); newo=np.maximum(oldo-amount,0)
    oldd=rng.exponential(120000,n); newd=oldd+amount
    flagged=(rng.random(n)<0.0004).astype(int)
    # synthetic fraud mechanism with relational-ish patterns
    fraud_score=(types=='TRANSFER')*1.1+(types=='CASH_OUT')*.7+(amount>200000)*.9+(oldo<amount)*.8+(flagged*1.5)+rng.normal(0,.6,n)
    isfraud=(fraud_score>2.0).astype(int)
    # add sparse fraud rate
    if isfraud.mean()<.01:
        idx=np.argsort(fraud_score)[-max(1,n//100):]; isfraud[idx]=1
    orig=[f'C{rng.integers(0,n//3):07d}' for _ in range(n)]
    dest=[f'C{rng.integers(n//3,n):07d}' for _ in range(n)]
    df=pd.DataFrame({'step':step,'type':types,'amount':amount,'nameOrig':orig,'oldbalanceOrg':oldo,'newbalanceOrig':newo,'nameDest':dest,'oldbalanceDest':oldd,'newbalanceDest':newd,'isFraud':isfraud,'isFlaggedFraud':flagged})
    path.parent.mkdir(parents=True,exist_ok=True); df.to_csv(path,index=False); return df

def load_data(limit=None):
    candidates=[RAW/'PS_20174392719_1491204439457_log.csv', RAW/'paysim.csv']
    src=next((p for p in candidates if p.exists()),None)
    if src is None:
        src=RAW/'paysim_demo.csv'; df=make_demo(src)
        source='synthetic PaySim-compatible demo (full PaySim can be dropped into data/raw)'
    else:
        df=pd.read_csv(src,nrows=limit)
        source=str(src.name)
    if limit and len(df)>limit: df=df.sample(limit,random_state=SEED)
    return df,source

def featurize(df):
    # Transaction graph: each transaction is a node; edges connect transactions
    # sharing the same origin or destination account. This makes fraud prediction
    # directly transaction-level while still using graph relationships.
    x=df[FEATURES].copy().astype(float)
    for t in TYPES: x['type_'+t]=(df['type']==t).astype(float)
    vals=x.values.astype(np.float32)
    scaler=StandardScaler(); vals=scaler.fit_transform(vals).astype(np.float32)
    y=df['isFraud'].astype(np.float32).values
    n=len(df)
    groups={}
    for col in ['nameOrig','nameDest']:
        for i,a in enumerate(df[col].astype(str).values):
            groups.setdefault((col,a),[]).append(i)
    edges=[]
    for ids in groups.values():
        # connect adjacent transactions within an account to keep the graph sparse
        for a,b in zip(ids,ids[1:]):
            edges.append((a,b)); edges.append((b,a))
    if not edges:
        edges=[(i,i) for i in range(n)]
    edge_index=torch.tensor(np.array(edges,dtype=np.int64).T, dtype=torch.long)
    return torch.tensor(vals), edge_index, torch.tensor(y), torch.arange(n), torch.arange(n), torch.tensor(y), pd.Index(df.index)

class GCN(nn.Module):
    def __init__(self,d,h=32):
        super().__init__(); self.w1=nn.Linear(d,h); self.w2=nn.Linear(h,1)
    def forward(self,x,edge_index):
        n=x.size(0)
        loops=torch.arange(n,device=x.device).repeat(2,1)
        ei=torch.cat([edge_index.to(x.device),loops],dim=1)
        A=torch.sparse_coo_tensor(ei,torch.ones(ei.size(1),device=x.device),(n,n)).coalesce()
        deg=torch.sparse.sum(A,1).to_dense().clamp(min=1)
        norm=deg.pow(-.5)
        H=norm[:,None]*torch.sparse.mm(A,norm[:,None]*x)
        H=torch.relu(self.w1(H))
        H=norm[:,None]*torch.sparse.mm(A,norm[:,None]*H)
        return self.w2(H).squeeze(1)

def state_avg(states, weights, noise_std=0):
    out={}; total=sum(weights)
    for k in states[0]:
        z=sum(s[k]*w for s,w in zip(states,weights))/total
        if noise_std>0: z=z+torch.randn_like(z)*noise_std
        out[k]=z
    return out

def train_client(x,e,y,global_state,epochs=2,lr=.01,dp_clip=1.0,dp_noise=.02):
    m=GCN(x.size(1)); m.load_state_dict(global_state); opt=torch.optim.Adam(m.parameters(),lr=lr)
    pos=max(y.sum().item(),1); neg=max((1-y).sum().item(),1); pw=torch.tensor([neg/pos])
    lossfn=nn.BCEWithLogitsLoss(pos_weight=pw)
    m.train()
    for _ in range(epochs):
        opt.zero_grad(); out=m(x,e); loss=lossfn(out,y); loss.backward()
        # DP-inspired gradient clipping + Gaussian noise on update (prototype)
        torch.nn.utils.clip_grad_norm_(m.parameters(),dp_clip)
        if dp_noise>0:
            for p in m.parameters():
                if p.grad is not None: p.grad += torch.randn_like(p.grad)*dp_noise
        opt.step()
    return m.state_dict(),len(y)

def eval_global(m,x,e,tx_src,y_tx):
    m.eval();
    with torch.no_grad(): p=torch.sigmoid(m(x,e)).numpy()
    txp=p[tx_src.numpy()]
    pred=(txp>=.5).astype(int); yy=y_tx.numpy().astype(int)
    return {'accuracy':float(accuracy_score(yy,pred)),'precision':float(precision_score(yy,pred,zero_division=0)),'recall':float(recall_score(yy,pred,zero_division=0)),'f1':float(f1_score(yy,pred,zero_division=0)),'auc':float(roc_auc_score(yy,txp)) if len(np.unique(yy))>1 else 0.0,'confusion_matrix':confusion_matrix(yy,pred).tolist()}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--limit',type=int,default=24000); ap.add_argument('--clients',type=int,default=3); ap.add_argument('--rounds',type=int,default=5); ap.add_argument('--epochs',type=int,default=1); ap.add_argument('--dp-noise',type=float,default=.02); args=ap.parse_args()
    df,source=load_data(args.limit)
    # stratified-ish client partition by origin hash, keeping fraud present where possible
    client_id=df['nameOrig'].apply(lambda s: hash(s)%args.clients).values
    client_data=[]
    for c in range(args.clients):
        part=df[client_id==c].copy()
        if len(part)<20: part=df.iloc[c::args.clients].copy()
        client_data.append(part)
    global_model=None; history=[]
    for r in range(args.rounds):
        states=[]; weights=[]
        for part in client_data:
            x,e,ny,src,dst,ytx,accounts=featurize(part)
            if global_model is None: global_model=GCN(x.size(1))
            st,n=train_client(x,e,ny,global_model.state_dict(),args.epochs,dp_noise=args.dp_noise)
            states.append(st); weights.append(n)
        global_model.load_state_dict(state_avg(states,weights,args.dp_noise*.5))
        # evaluate on pooled sample
        pool=pd.concat(client_data,ignore_index=True)
        x,e,ny,src,dst,ytx,accounts=featurize(pool)
        met=eval_global(global_model,x,e,src,ytx); met['round']=r+1; history.append(met)
        print(f'Round {r+1}/{args.rounds}: F1={met["f1"]:.4f} Recall={met["recall"]:.4f} AUC={met["auc"]:.4f}')
    torch.save({'state_dict':global_model.state_dict(),'input_dim':x.size(1)},MOD/'fedshield_gcn.pt')
    out={'source':source,'rows':len(df),'fraud_count':int(df.isFraud.sum()),'fraud_rate':float(df.isFraud.mean()),'clients':args.clients,'rounds':args.rounds,'dp_noise':args.dp_noise,'history':history,'final':history[-1]}
    (RES/'results.json').write_text(json.dumps(out,indent=2))
    # save a compact scored sample for dashboard
    pool=pd.concat(client_data,ignore_index=True).head(5000).copy(); x,e,ny,src,dst,ytx,accounts=featurize(pool)
    with torch.no_grad(): probs=torch.sigmoid(global_model(x,e))[src].numpy()
    pool['risk_score']=probs; pool['prediction']=(probs>=.5).astype(int); pool.to_csv(RES/'scored_transactions.csv',index=False)
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
